#ifndef _delay_us
#define _delay_us(n) delayMicroseconds(n)
#endif

#ifndef _delay_ms
#define _delay_ms(n) delay(n)
#endif
